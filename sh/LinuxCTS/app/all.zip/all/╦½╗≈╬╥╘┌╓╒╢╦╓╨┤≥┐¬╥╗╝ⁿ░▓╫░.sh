#!/bin/bash
sudo apt install ./*.deb -y
echo 按回车关闭
read
